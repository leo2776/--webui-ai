document.addEventListener('DOMContentLoaded', async () => {
  const settingsToggle = document.getElementById('settings-toggle');
  const settingsPanel = document.getElementById('settings-panel');
  const apiSelect = document.getElementById('api-select');
  const apiKeyInput = document.getElementById('api-key');
  const fetchModelsBtn = document.getElementById('fetch-models-btn');
  const modelSelect = document.getElementById('model-select');
  const saveSettingsBtn = document.getElementById('save-settings');
  const chatContainer = document.getElementById('chat-container');
  const summarizeBtn = document.getElementById('summarize-btn');
  const userInput = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  const encrypt = (text) => btoa(text);
  const decrypt = (encoded) => {
    try { return atob(encoded); } catch(e) { return ""; }
  };

  // 載入設定
  const loadSettings = async () => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_config`]);
    const config = result[`${selectedApi}_config`] || {};
    
    apiKeyInput.value = decrypt(config.key || "");
    
    // 如果有儲存的模型清單，則載入
    if (config.availableModels && config.availableModels.length > 0) {
      updateModelDropdown(config.availableModels, config.model);
    } else {
      modelSelect.innerHTML = '<option value="">請先獲取模型清單</option>';
    }
  };

  const updateModelDropdown = (models, selectedModel) => {
    modelSelect.innerHTML = '';
    models.forEach(m => {
      const option = document.createElement('option');
      option.value = m;
      option.textContent = m;
      if (m === selectedModel) option.selected = true;
      modelSelect.appendChild(option);
    });
  };

  await loadSettings();
  apiSelect.addEventListener('change', loadSettings);

  settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.toggle('hidden');
  });

  // 動態獲取模型清單
  fetchModelsBtn.addEventListener('click', async () => {
    const selectedApi = apiSelect.value;
    const apiKey = apiKeyInput.value.trim();
    
    if (!apiKey) {
      alert('請先輸入 API 金鑰');
      return;
    }

    fetchModelsBtn.disabled = true;
    fetchModelsBtn.textContent = '正在獲取...';

    try {
      let models = [];
      if (selectedApi === 'openai') {
        const res = await fetch('https://api.openai.com/v1/models', {
          headers: { 'Authorization': `Bearer ${apiKey}` }
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || '獲取失敗');
        // 只篩選 chat 模型
        models = data.data.filter(m => m.id.includes('gpt')).map(m => m.id);
      } else if (selectedApi === 'gemini') {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || '獲取失敗');
        // 篩選支援 generateContent 的模型
        models = data.models
          .filter(m => m.supportedGenerationMethods.includes('generateContent'))
          .map(m => m.name.replace('models/', ''));
      }

      if (models.length > 0) {
        updateModelDropdown(models);
        alert(`成功獲取 ${models.length} 個可用模型！`);
      } else {
        alert('未找到可用模型');
      }
    } catch (e) {
      alert('錯誤: ' + e.message);
    } finally {
      fetchModelsBtn.disabled = false;
      fetchModelsBtn.textContent = '🔄 獲取可用模型清單';
    }
  });

  // 儲存設定
  saveSettingsBtn.addEventListener('click', async () => {
    const selectedApi = apiSelect.value;
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;
    
    // 獲取當前下拉選單中的所有模型以便長期儲存
    const availableModels = Array.from(modelSelect.options).map(opt => opt.value).filter(v => v !== "");
    
    const config = {
      key: encrypt(key),
      model: model,
      availableModels: availableModels
    };
    
    const data = {};
    data[`${selectedApi}_config`] = config;
    await chrome.storage.local.set(data);
    
    alert('設定已儲存！');
    settingsPanel.classList.add('hidden');
  });

  const addMessage = (role, text) => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    msgDiv.textContent = text;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    return msgDiv;
  };

  const getPageContent = () => {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => resolve({ error: "提取內容超時" }), 5000);
      chrome.runtime.sendMessage({ action: "extractContent" }, (response) => {
        clearTimeout(timeout);
        resolve(response || { error: "無法提取內容" });
      });
    });
  };

  const callAI = async (prompt, pageContent = "") => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_config`]);
    const config = result[`${selectedApi}_config`] || {};
    const apiKey = decrypt(config.key || "");
    const model = config.model;

    if (!apiKey) throw new Error('請先在設定中輸入 API 金鑰');
    if (!model) throw new Error('請先獲取並選擇一個模型');

    const truncatedContent = pageContent.substring(0, 8000);
    const fullPrompt = truncatedContent 
      ? `網頁內容：\n${truncatedContent}\n\n問題：${prompt}`
      : prompt;

    if (selectedApi === 'openai') {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model,
          messages: [{ role: "user", content: fullPrompt }]
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message || `OpenAI 錯誤 ${response.status}`);
      return data.choices[0].message.content;

    } else if (selectedApi === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: fullPrompt }] }]
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message || `Gemini 錯誤 ${response.status}`);
      return data.candidates[0].content.parts[0].text;
    }
  };

  summarizeBtn.addEventListener('click', async () => {
    if (summarizeBtn.disabled) return;
    summarizeBtn.disabled = true;
    addMessage('user', '請幫我總結這個頁面。');
    const loadingMsg = addMessage('ai', '正在讀取並生成總結...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const summary = await callAI("請用繁體中文簡潔地總結這個網頁的重點，使用條列式。", pageData.content || "");
      loadingMsg.textContent = summary;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      summarizeBtn.disabled = false;
    }
  });

  const handleSend = async () => {
    const text = userInput.value.trim();
    if (!text || sendBtn.disabled) return;
    userInput.value = '';
    sendBtn.disabled = true;
    addMessage('user', text);
    const loadingMsg = addMessage('ai', '思考中...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const response = await callAI(text, pageData.content || "");
      loadingMsg.textContent = response;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      sendBtn.disabled = false;
    }
  };

  sendBtn.addEventListener('click', handleSend);
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });
});
