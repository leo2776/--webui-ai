// 點擊圖標時開啟側邊欄
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// 監聽來自側邊欄的內容提取請求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractContent") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            const bodyClone = document.body.cloneNode(true);
            const tagsToRemove = ['script', 'style', 'nav', 'footer', 'header', 'aside', 'iframe', 'noscript'];
            tagsToRemove.forEach(tag => {
              const elements = bodyClone.querySelectorAll(tag);
              elements.forEach(el => el.remove());
            });
            let text = bodyClone.innerText || bodyClone.textContent;
            return text.replace(/\s+/g, ' ').trim().substring(0, 10000);
          }
        }, (results) => {
          if (results && results[0]) {
            sendResponse({ content: results[0].result });
          } else {
            sendResponse({ error: "無法提取內容" });
          }
        });
      }
    });
    return true; // 保持通道開啟以進行非同步回應
  }
});
