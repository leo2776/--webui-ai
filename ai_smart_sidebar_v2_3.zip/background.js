// 點擊圖標時開啟側邊欄
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// 監聽來自側邊欄的內容提取請求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractContent") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0] || !tabs[0].id) {
        sendResponse({ error: "找不到活動分頁" });
        return;
      }

      // 檢查是否為受保護的頁面 (如 chrome://)
      if (tabs[0].url.startsWith('chrome://') || tabs[0].url.startsWith('edge://')) {
        sendResponse({ error: "無法在瀏覽器系統頁面使用此功能" });
        return;
      }

      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          try {
            // 優先獲取標題
            const title = document.title;
            
            // 嘗試獲取主要內容
            let content = "";
            const article = document.querySelector('article');
            const main = document.querySelector('main');
            
            if (article) {
              content = article.innerText;
            } else if (main) {
              content = main.innerText;
            } else {
              // 備用方案：清理 body
              const bodyClone = document.body.cloneNode(true);
              const tagsToRemove = ['script', 'style', 'nav', 'footer', 'header', 'aside', 'iframe', 'noscript', 'svg'];
              tagsToRemove.forEach(tag => {
                const elements = bodyClone.querySelectorAll(tag);
                elements.forEach(el => el.remove());
              });
              content = bodyClone.innerText || bodyClone.textContent;
            }

            // 清理空白並限制長度
            const cleanContent = `標題: ${title}\n\n內容: ${content.replace(/\s+/g, ' ').trim().substring(0, 12000)}`;
            return cleanContent;
          } catch (e) {
            return "提取失敗: " + e.message;
          }
        }
      }, (results) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: "腳本執行失敗: " + chrome.runtime.lastError.message });
        } else if (results && results[0]) {
          sendResponse({ content: results[0].result });
        } else {
          sendResponse({ error: "無法獲取提取結果" });
        }
      });
    });
    return true; // 保持通道開啟
  }
});
