document.addEventListener('DOMContentLoaded', async () => {
  const settingsToggle = document.getElementById('settings-toggle');
  const settingsPanel = document.getElementById('settings-panel');
  const apiSelect = document.getElementById('api-select');
  const apiKeyInput = document.getElementById('api-key');
  const saveSettingsBtn = document.getElementById('save-settings');
  const chatContainer = document.getElementById('chat-container');
  const summarizeBtn = document.getElementById('summarize-btn');
  const userInput = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  // 載入設定
  const loadSettings = async () => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_key`]);
    apiKeyInput.value = result[`${selectedApi}_key`] || '';
  };

  await loadSettings();
  apiSelect.addEventListener('change', loadSettings);

  // 切換設定面板
  settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.toggle('hidden');
  });

  // 儲存設定
  saveSettingsBtn.addEventListener('click', async () => {
    const selectedApi = apiSelect.value;
    const key = apiKeyInput.value.trim();
    const data = {};
    data[`${selectedApi}_key`] = key;
    await chrome.storage.local.set(data);
    alert('設定已儲存！');
    settingsPanel.classList.add('hidden');
  });

  // 新增訊息到對話框
  const addMessage = (role, text) => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    msgDiv.textContent = text;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    return msgDiv;
  };

  // 獲取網頁內容
  const getPageContent = () => {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        resolve({ error: "提取內容超時" });
      }, 5000);

      chrome.runtime.sendMessage({ action: "extractContent" }, (response) => {
        clearTimeout(timeout);
        if (response && response.content) {
          resolve(response);
        } else {
          resolve({ error: response ? response.error : "無法提取內容" });
        }
      });
    });
  };

  // 帶有超時的 fetch
  const fetchWithTimeout = async (url, options, timeout = 30000) => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(id);
      return response;
    } catch (e) {
      clearTimeout(id);
      throw e;
    }
  };

  // 呼叫 AI API
  const callAI = async (prompt, pageContent = "") => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_key`]);
    const apiKey = result[`${selectedApi}_key`];

    if (!apiKey) {
      throw new Error('請先在設定中輸入 API 金鑰');
    }

    // 限制內容長度，避免 API 處理過久
    const truncatedContent = pageContent.substring(0, 6000);
    const fullPrompt = truncatedContent 
      ? `以下是網頁內容：\n\n${truncatedContent}\n\n問題：${prompt}`
      : prompt;

    try {
      if (selectedApi === 'openai') {
        const response = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [{ role: "user", content: fullPrompt }],
            temperature: 0.7
          })
        });
        
        const data = await response.json();
        if (!response.ok) throw new Error(data.error?.message || `HTTP 錯誤 ${response.status}`);
        return data.choices[0].message.content;

      } else if (selectedApi === 'gemini') {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${apiKey}`;
        const response = await fetchWithTimeout(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: fullPrompt }] }]
          })
        });

        const data = await response.json();
        if (!response.ok) {
          if (data.error?.message?.includes("not found")) {
            // 備援方案
            const fallbackUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`;
            const fallbackRes = await fetchWithTimeout(fallbackUrl, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }] })
            });
            const fallbackData = await fallbackRes.json();
            if (!fallbackRes.ok) throw new Error(fallbackData.error?.message || "Gemini API 呼叫失敗");
            return fallbackData.candidates[0].content.parts[0].text;
          }
          throw new Error(data.error?.message || `HTTP 錯誤 ${response.status}`);
        }
        return data.candidates[0].content.parts[0].text;
      }
    } catch (e) {
      if (e.name === 'AbortError') throw new Error("API 請求超時，請檢查網路或稍後再試");
      throw e;
    }
  };

  // 總結按鈕
  summarizeBtn.addEventListener('click', async () => {
    if (summarizeBtn.disabled) return;
    summarizeBtn.disabled = true;
    
    addMessage('user', '請幫我總結這個頁面。');
    const loadingMsg = addMessage('ai', '正在讀取並生成總結...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const content = pageData.content || "無法提取完整內容。";
      const summary = await callAI("請用繁體中文簡潔地總結這個網頁的重點，使用條列式。", content);
      loadingMsg.textContent = summary;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      summarizeBtn.disabled = false;
    }
  });

  // 發送訊息
  const handleSend = async () => {
    const text = userInput.value.trim();
    if (!text || sendBtn.disabled) return;

    userInput.value = '';
    sendBtn.disabled = true;
    addMessage('user', text);
    const loadingMsg = addMessage('ai', '思考中...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const response = await callAI(text, pageData.content || "");
      loadingMsg.textContent = response;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      sendBtn.disabled = false;
    }
  };

  sendBtn.addEventListener('click', handleSend);
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });
});
