document.addEventListener('DOMContentLoaded', async () => {
  const settingsToggle = document.getElementById('settings-toggle');
  const settingsPanel = document.getElementById('settings-panel');
  const apiSelect = document.getElementById('api-select');
  const apiKeyInput = document.getElementById('api-key');
  const saveSettingsBtn = document.getElementById('save-settings');
  const chatContainer = document.getElementById('chat-container');
  const summarizeBtn = document.getElementById('summarize-btn');
  const userInput = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  // 載入設定
  const loadSettings = async () => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_key`]);
    apiKeyInput.value = result[`${selectedApi}_key`] || '';
  };

  await loadSettings();
  apiSelect.addEventListener('change', loadSettings);

  // 切換設定面板
  settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.toggle('hidden');
  });

  // 儲存設定
  saveSettingsBtn.addEventListener('click', async () => {
    const selectedApi = apiSelect.value;
    const key = apiKeyInput.value.trim();
    const data = {};
    data[`${selectedApi}_key`] = key;
    await chrome.storage.local.set(data);
    alert('設定已儲存！');
    settingsPanel.classList.add('hidden');
  });

  // 新增訊息到對話框
  const addMessage = (role, text) => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    msgDiv.textContent = text;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    return msgDiv;
  };

  // 獲取網頁內容
  const getPageContent = () => {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "extractContent" }, (response) => {
        resolve(response);
      });
    });
  };

  // 呼叫 AI API
  const callAI = async (prompt, pageContent = "") => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_key`]);
    const apiKey = result[`${selectedApi}_key`];

    if (!apiKey) {
      throw new Error('請先在設定中輸入 API 金鑰');
    }

    const fullPrompt = pageContent 
      ? `以下是當前網頁的內容：\n\n${pageContent}\n\n使用者問題：${prompt}`
      : prompt;

    if (selectedApi === 'openai') {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [{ role: "user", content: fullPrompt }],
          temperature: 0.7
        })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);
      return data.choices[0].message.content;
    } else if (selectedApi === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: fullPrompt }] }]
        })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);
      return data.candidates[0].content.parts[0].text;
    }
  };

  // 總結按鈕
  summarizeBtn.addEventListener('click', async () => {
    addMessage('user', '請幫我總結這個頁面。');
    const loadingMsg = addMessage('ai', '正在閱讀網頁內容...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      if (pageData.error) throw new Error(pageData.error);
      
      const summary = await callAI("請用繁體中文簡潔地總結這個網頁的重點，使用條列式。", pageData.content);
      loadingMsg.textContent = summary;
      loadingMsg.classList.remove('loading');
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
      loadingMsg.classList.remove('loading');
    }
  });

  // 發送訊息
  const handleSend = async () => {
    const text = userInput.value.trim();
    if (!text) return;

    userInput.value = '';
    addMessage('user', text);
    const loadingMsg = addMessage('ai', '思考中...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const response = await callAI(text, pageData.content || "");
      loadingMsg.textContent = response;
      loadingMsg.classList.remove('loading');
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
      loadingMsg.classList.remove('loading');
    }
  };

  sendBtn.addEventListener('click', handleSend);
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });
});
