document.addEventListener('DOMContentLoaded', async () => {
  const settingsToggle = document.getElementById('settings-toggle');
  const settingsPanel = document.getElementById('settings-panel');
  const apiSelect = document.getElementById('api-select');
  const modelNameInput = document.getElementById('model-name');
  const apiKeyInput = document.getElementById('api-key');
  const saveSettingsBtn = document.getElementById('save-settings');
  const chatContainer = document.getElementById('chat-container');
  const summarizeBtn = document.getElementById('summarize-btn');
  const userInput = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  // 簡單的加密/解密 (Base64 混淆)
  const encrypt = (text) => btoa(text);
  const decrypt = (encoded) => {
    try { return atob(encoded); } catch(e) { return ""; }
  };

  // 載入設定
  const loadSettings = async () => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_config`]);
    const config = result[`${selectedApi}_config`] || {};
    
    modelNameInput.value = config.model || "";
    apiKeyInput.value = decrypt(config.key || "");
  };

  await loadSettings();
  apiSelect.addEventListener('change', loadSettings);

  // 切換設定面板
  settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.toggle('hidden');
  });

  // 儲存設定
  saveSettingsBtn.addEventListener('click', async () => {
    const selectedApi = apiSelect.value;
    const key = apiKeyInput.value.trim();
    const model = modelNameInput.value.trim();
    
    const config = {
      key: encrypt(key),
      model: model
    };
    
    const data = {};
    data[`${selectedApi}_config`] = config;
    await chrome.storage.local.set(data);
    
    alert('設定已加密儲存！');
    settingsPanel.classList.add('hidden');
  });

  const addMessage = (role, text) => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    msgDiv.textContent = text;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    return msgDiv;
  };

  const getPageContent = () => {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => resolve({ error: "提取內容超時" }), 5000);
      chrome.runtime.sendMessage({ action: "extractContent" }, (response) => {
        clearTimeout(timeout);
        resolve(response || { error: "無法提取內容" });
      });
    });
  };

  const fetchWithTimeout = async (url, options, timeout = 30000) => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(id);
      return response;
    } catch (e) {
      clearTimeout(id);
      throw e;
    }
  };

  // 呼叫 AI API
  const callAI = async (prompt, pageContent = "") => {
    const selectedApi = apiSelect.value;
    const result = await chrome.storage.local.get([`${selectedApi}_config`]);
    const config = result[`${selectedApi}_config`] || {};
    const apiKey = decrypt(config.key || "");

    if (!apiKey) throw new Error('請先在設定中輸入 API 金鑰');

    const truncatedContent = pageContent.substring(0, 8000);
    const fullPrompt = truncatedContent 
      ? `網頁內容：\n${truncatedContent}\n\n問題：${prompt}`
      : prompt;

    if (selectedApi === 'openai') {
      const model = config.model || "gpt-4o-mini";
      const response = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model,
          messages: [{ role: "user", content: fullPrompt }]
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message || `OpenAI 錯誤 ${response.status}`);
      return data.choices[0].message.content;

    } else if (selectedApi === 'gemini') {
      // 嘗試的模型列表
      const modelsToTry = config.model ? [config.model] : ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro"];
      let lastError = "";

      for (const model of modelsToTry) {
        try {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
          const response = await fetchWithTimeout(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: fullPrompt }] }]
            })
          });
          const data = await response.json();
          if (response.ok) return data.candidates[0].content.parts[0].text;
          lastError = data.error?.message || `HTTP ${response.status}`;
          if (!lastError.includes("not found")) break; // 如果不是找不到模型，就不用試下一個了
        } catch (e) {
          lastError = e.message;
        }
      }
      throw new Error(`Gemini 錯誤: ${lastError}`);
    }
  };

  summarizeBtn.addEventListener('click', async () => {
    if (summarizeBtn.disabled) return;
    summarizeBtn.disabled = true;
    addMessage('user', '請幫我總結這個頁面。');
    const loadingMsg = addMessage('ai', '正在讀取並生成總結...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const summary = await callAI("請用繁體中文簡潔地總結這個網頁的重點，使用條列式。", pageData.content || "");
      loadingMsg.textContent = summary;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      summarizeBtn.disabled = false;
    }
  });

  const handleSend = async () => {
    const text = userInput.value.trim();
    if (!text || sendBtn.disabled) return;
    userInput.value = '';
    sendBtn.disabled = true;
    addMessage('user', text);
    const loadingMsg = addMessage('ai', '思考中...');
    loadingMsg.classList.add('loading');

    try {
      const pageData = await getPageContent();
      const response = await callAI(text, pageData.content || "");
      loadingMsg.textContent = response;
    } catch (error) {
      loadingMsg.textContent = `錯誤：${error.message}`;
    } finally {
      loadingMsg.classList.remove('loading');
      sendBtn.disabled = false;
    }
  };

  sendBtn.addEventListener('click', handleSend);
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });
});
